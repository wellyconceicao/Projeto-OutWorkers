---

title: Theme Test Event
layout: event-2.0
permalink: /event-example/

---

This is my event for testing the theme.